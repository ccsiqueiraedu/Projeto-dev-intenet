Projeto corrigido - pronto para rodar

Instruções:
- Java 17 recomendado.
- Rodar: mvn spring-boot:run dentro da pasta endereco-via-cep
- Aplicação na porta 8080 (http://localhost:8080/enderecos)
- H2 console: http://localhost:8080/h2-console (jdbc:h2:mem:endereco-db, user=sa, sem senha)
